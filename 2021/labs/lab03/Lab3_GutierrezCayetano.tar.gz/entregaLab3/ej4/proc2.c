#include <stdio.h>

void absolute(int x, int *y) {
    // Completar aqui
    if(x>=*y){
        *y = x;
    }
    else{
        *y = -x;
    }
}

int main(void) {
    // Completar aqui
    int a = -98;
    int res = 0;

    absolute(a, &res);

    printf("%d\n", res);
    return 0;
}

